import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/patient/doctorprofile.dart';
import 'package:project/patient/rootpage.dart';


class ChatWithDoctor extends StatefulWidget {
  const ChatWithDoctor({super.key});

  @override
  State<ChatWithDoctor> createState() => _ChatWithDoctorState();
}

class _ChatWithDoctorState extends State<ChatWithDoctor> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xffFF67CE),
              ),
            ),
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding:const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xffFF67CE),
                      width: 2,
                    ),
                  ),
                  child: IconButton(
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: Color(0xffFF67CE),
                      size: 18,
                    ),
                    onPressed: () {
                           Navigator.push(context, MaterialPageRoute(builder: (context)=> RootPage()));
                    },
                  ),
                ),
              ),
              Center(child: Image.asset("assets/images/profilepink.png",width: 130,height: 130,),),

              Text(
                "Doctor",
                style: GoogleFonts.poppins(
                  fontSize: 23,
                  fontWeight: FontWeight.w700,
                  color: const Color(0xffFF67CE),
                ),
              ),

              SizedBox(height: 20,),

                Text("doctor@gmail.com",style: GoogleFonts.poppins(
                  color: const Color(0xffFF67CE),
                  fontWeight: FontWeight.w700,
                  fontSize: 18,
                ),),

              Align(
                alignment: Alignment.center,
                child: Center(
                  child: Text("You are now connected with each other.",style: GoogleFonts.poppins(
                    color: const Color(0xffFF67CE),
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),),
                ),
              ),

              Align(
                alignment: Alignment.center,
                child: ElevatedButton(
                  onPressed: () {
                     Navigator.push(context, MaterialPageRoute(builder: (context)=> DoctorProfile()));
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xffFF67CE),
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: Text(
                    "View Profile",
                    style: GoogleFonts.poppins(
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),





              SizedBox(height: 300,),

              TextField(
                decoration: InputDecoration(
                  hintText: 'Type Message',
                  suffixIcon: Icon(Icons.camera_alt,color: Colors.black,),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: BorderSide(color: Color(0xffFF67CE),width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(
                      color: Color(0xffFF67CE),
                      width: 2,
                    ),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide: const BorderSide(
                      color: Color(0xffFF67CE),
                      width: 2,
                    ),
                  ),
                ),
              ),




            ],
          ),
        ),
      ),
    );
  }
}
