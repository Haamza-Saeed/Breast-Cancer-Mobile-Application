import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/login.dart';
import 'package:project/signup1.dart';

class ForgetPassword extends StatefulWidget {
  const ForgetPassword({super.key});

  @override
  State<ForgetPassword> createState() => _ForgetPasswordState();
}

class _ForgetPasswordState extends State<ForgetPassword> {
  TextEditingController emailController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xffFF67CE),
              ),
            ),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding:const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xffFF67CE),
                    width: 2,
                  ),
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.arrow_back_ios_new,
                    color: Color(0xffFF67CE),
                    size: 18,
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                  },
                ),
              ),
            ),
            Image.asset("assets/images/elock.png",width: 373, height: 249,),
            SizedBox(height: 20,),
            Text("Enter your email address",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 27,
              color: Color(0xffFF67CE),
            ),),

            SizedBox(height: 15,),
            Align(
              alignment: Alignment.centerLeft,
              child: Text("Email",style: GoogleFonts.poppins(
                color: Color(0xff00AEEF),
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),),
            ),
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.blue,width: 2),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Colors.blue,
                    width: 2,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Colors.blueAccent,
                    width: 2,
                  ),
                ),
              ),
            ),

            SizedBox(height: 55,),
            Column(children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Text("Note:",style: GoogleFonts.poppins(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: Color(0xff00AEEF),
                ),),
              ),
              Text("To reset your password, please enter the email address you used when you signed up. We will send a link to that email address where you can create a new password.",style: GoogleFonts.poppins(
                fontSize: 16,
                fontWeight: FontWeight.w400,
                color: Color(0xff00AEEF),
              ),)
            ],),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {

                  if(emailController.text.isEmpty){
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Email cannot be empty")));
                    return;
                  }

                  if(!emailController.text.contains('@')){
                    ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text("Your Email doesnot have @. Please enter @ too.")));
                    return;
                  }
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> Signup1()));

                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    "Send",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xffFFFFFF),
                    ),
                  ),
                ),
              ),
            ),


          ],),
        ),
      ),
    );
  }
}
