import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/admin/adminhomepage.dart';
import 'package:project/admin/adminmanageprofile.dart';
import 'package:project/admin/adminnotification.dart';
import 'package:project/admin/viewdoctors.dart';





class AdminRootPage extends StatefulWidget {
  const AdminRootPage({super.key});

  @override
  State<AdminRootPage> createState() => _AdminRootPageState();
}

class _AdminRootPageState extends State<AdminRootPage> {
  @override
  int selectedindex = 0;
  List<Widget> screenList = [AdminHomepage(), ViewDoctors(), AdminManageProfile(), AdminNotifications()];
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xff00EFAB),
              ),
            ),
          ),
        ),
      ),

      body: screenList.elementAt(selectedindex),
      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xff00EFAB),
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.white,
          showSelectedLabels: true,

          selectedFontSize: 15,

          onTap: (val){
            selectedindex = val;
            setState(() {});
          },
          currentIndex: selectedindex,
          items:[
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon:  Image.asset("assets/images/viewdoctors.png",width: 25,height: 25,), label: 'View Doctor'),
            BottomNavigationBarItem(icon:Image.asset("assets/images/profilewhite.png",width: 25,height: 25,),label: 'Profile'),
            BottomNavigationBarItem(icon: Icon(Icons.notifications), label: 'Notifications'),
          ]),
    );
  }
}
