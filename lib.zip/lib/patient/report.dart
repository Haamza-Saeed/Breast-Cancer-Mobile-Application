import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/patient/rootpage.dart';

class Report extends StatelessWidget {
  const Report({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xffFF67CE),
              ),
            ),
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xffFF67CE),
                    width: 2,
                  ),
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.arrow_back_ios_new,
                    color: Color(0xffFF67CE),
                    size: 18,
                  ),
                  onPressed: () {
                         Navigator.push(context, MaterialPageRoute(builder: (context)=> RootPage()));
                  },
                ),
              ),
            ),
            Image.asset("assets/images/announcments.png",width: 373, height: 249,),
            SizedBox(height: 10,),

            Text("My Report",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 27,
              color: Color(0xffFF67CE),
            ),),

            SizedBox(height: 130,),

            Center(child: Text("No reports yet!",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 13,
              color: Color(0xffFF67CE),
            ),),)
          ],),
        ),
      ),
    );
  }
}
