import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/doctor/doctorannouncements.dart';
import 'package:project/doctor/doctorhomepage.dart';
import 'package:project/doctor/doctormanageprofile.dart';
import 'package:project/doctor/doctornotification.dart';





class DoctorRootPage extends StatefulWidget {
  const DoctorRootPage({super.key});

  @override
  State<DoctorRootPage> createState() => _DoctorRootPageState();
}

class _DoctorRootPageState extends State<DoctorRootPage> {
  @override
  int selectedindex = 0;
  List<Widget> screenList = [DoctorHomepage(), DoctorAnnouncements(), DoctorManageProfile(), DoctorNotifications()];
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xff00AEEF),
              ),
            ),
          ),
        ),
      ),

      body: screenList.elementAt(selectedindex),
      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xff00AEEF),
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.white,
          showSelectedLabels: true,

          selectedFontSize: 15,

          onTap: (val){
            selectedindex = val;
            setState(() {});
          },
          currentIndex: selectedindex,
          items:[
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Image.asset("assets/images/megaphone.png",width: 25,height: 25,), label: 'Announcements'),
            BottomNavigationBarItem(icon:Image.asset("assets/images/profilewhite.png",width: 25,height: 25,),label: 'Profile'),
            BottomNavigationBarItem(icon: Icon(Icons.notifications), label: 'Notifications'),
          ]),
    );
  }
}
