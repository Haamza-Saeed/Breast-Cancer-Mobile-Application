import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/doctor/chatroom.dart';
import 'package:project/doctor/chatwithpatients.dart';
import 'package:project/doctor/doctorchatrequest.dart';
import 'package:project/doctor/doctorfeedback.dart';
import 'package:project/doctor/doctorsettings.dart';
import 'package:project/doctor/uploadexercise.dart';
import 'package:project/login.dart';


class DoctorHomepage extends StatelessWidget {
  const DoctorHomepage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
          }, icon:  Icon(Icons.logout,size: 30,color: Colors.black,),)
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            SizedBox(height: 20),
            Center(
              child: Image.asset(
                "assets/images/profileblue.png",
                width: 100,
                height: 100,
              ),
            ),
            SizedBox(height: 20),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Doctor",
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w700,
                  fontSize: 27,
                  color: Color(0xff00AEEF),
                ),
              ),
            ),
            SizedBox(height: 15),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const DoctorSettings()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(Icons.settings, color: Colors.white, size: 20),
                      SizedBox(width: 15),
                      Text(
                        "Settings",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const DoctorFeedBack()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset("assets/images/smileface.png", width: 24),
                      SizedBox(width: 15),
                      Text(
                        "Feedback",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const Login()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(Icons.logout, color: Colors.white, size: 20),
                      SizedBox(width: 15),
                      Text(
                        "Logout",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(children: [
            Image.asset("assets/images/doctorhomepage.png",width: 373, height: 249,),
            SizedBox(height: 20,),

            Text("Welcome Doctor!",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 27,
              color: Color(0xff00AEEF),
            ),),

            SizedBox(height: 15,),


            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> const DoctorChatRequest()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset("assets/images/chat.png", width: 24),
                      SizedBox(width: 15,),
                      Text(
                        "View Chat Request ",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const ChatRoom()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.chat,color: const Color(0xffFFFFFF),size: 20,),
                      SizedBox(width: 15,),
                      Text(
                        "Chat Room",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=>const UploadExercise()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.upload_file_sharp,color: const Color(0xffFFFFFF),size: 20,),
                      SizedBox(width: 15,),
                      Text(
                        "Upload Exercise",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const ChatWithPatients()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.chat,color: const Color(0xffFFFFFF),size: 20,),
                      SizedBox(width: 15,),
                      Text(
                        "Chat with Patients",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

          ],),
        ),
      ),
    );
  }
}
