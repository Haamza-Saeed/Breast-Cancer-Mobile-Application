import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/admin/addadoctor.dart';
import 'package:project/admin/adminannouncements.dart';
import 'package:project/admin/adminfeedback.dart';
import 'package:project/admin/adminmanageusers.dart';
import 'package:project/admin/adminsettings.dart';
import 'package:project/admin/manageexercise.dart';
import 'package:project/admin/monitorchat.dart';
import 'package:project/login.dart';


class AdminHomepage extends StatelessWidget {
  const AdminHomepage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        actions: [
          IconButton(onPressed: (){
            Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
          }, icon:  Icon(Icons.logout,size: 30,color: Colors.black,),)
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            SizedBox(height: 20),
            Center(
              child: Image.asset(
                "assets/images/profilegreen.png",
                width: 100,
                height: 100,
              ),
            ),
            SizedBox(height: 20),
            Align(
              alignment: Alignment.center,
              child: Text(
                "Admin",
                style: GoogleFonts.poppins(
                  fontWeight: FontWeight.w700,
                  fontSize: 27,
                  color: Color(0xff00EFAB),
                ),
              ),
            ),
            SizedBox(height: 15),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const AdminSettings()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(Icons.settings, color: Colors.white, size: 20),
                      SizedBox(width: 15),
                      Text(
                        "Settings",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context)=>const AdminFeedback()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Image.asset("assets/images/smileface.png", width: 24),
                      SizedBox(width: 15),
                      Text(
                        "Feedback & Responses",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const Login()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Icon(Icons.logout, color: Colors.white, size: 20),
                      SizedBox(width: 15),
                      Text(
                        "Logout",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: Colors.white,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(children: [
            Image.asset("assets/images/adminhomepage.png",width: 373, height: 249,),
            SizedBox(height: 20,),

            Text("Welcome Admin!",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 27,
              color: Color(0xff00EFAB),
            ),),

            SizedBox(height: 15,),


            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                 Navigator.push(context, MaterialPageRoute(builder: (context)=> const AdminManageUsers()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset("assets/images/manageusers.png", width: 24),
                      SizedBox(width: 15,),
                      Text(
                        "Manage Users ",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const MonitorChats()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.chat,color: const Color(0xffFFFFFF),size: 20,),
                      SizedBox(width: 15,),
                      Text(
                        "Monitor Chats",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),

            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>const ManageExercise()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Icon(Icons.upload_file_sharp,color: const Color(0xffFFFFFF),size: 20,),
                      SizedBox(width: 15,),
                      Text(
                        "Manage Exercise",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),


            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context)=> const AddADoctor()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset("assets/images/adddoctor.png", width: 24),
                      SizedBox(width: 15,),
                      Text(
                        "Add a Doctor ",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

            SizedBox(height: 15,),


            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                   Navigator.push(context, MaterialPageRoute(builder: (context)=> const AdminAnnouncements()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00EFAB),
                  padding: const EdgeInsets.symmetric(vertical: 17),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Image.asset("assets/images/megaphone.png", width: 24),
                      SizedBox(width: 15,),
                      Text(
                        "Announcements ",
                        style: GoogleFonts.poppins(
                          fontSize: 17,
                          fontWeight: FontWeight.w700,
                          color: const Color(0xffFFFFFF),
                        ),
                      ),

                    ],
                  ),
                ),
              ),
            ),

          ],),
        ),
      ),
    );
  }
}
