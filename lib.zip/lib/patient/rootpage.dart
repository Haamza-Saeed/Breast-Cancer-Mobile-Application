import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/patient/announcements.dart';
import 'package:project/patient/homepage.dart';
import 'package:project/patient/notifications.dart';
import 'package:project/patient/profile.dart';


class RootPage extends StatefulWidget {
  const RootPage({super.key});

  @override
  State<RootPage> createState() => _RootPageState();
}

class _RootPageState extends State<RootPage> {
  @override
  int selectedindex = 0;
  List<Widget> screenList = [Homepage(), Announcements(), PatientProfile(), Notifications()];
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xffFF67CE),
              ),
            ),
          ),
        ),
      ),

      body: screenList.elementAt(selectedindex),
      bottomNavigationBar: BottomNavigationBar(
          type: BottomNavigationBarType.fixed,
          backgroundColor: const Color(0xffFF67CE),
          selectedItemColor: Colors.black,
          unselectedItemColor: Colors.white,
          showSelectedLabels: true,

          selectedFontSize: 15,

          onTap: (val){
            selectedindex = val;
            setState(() {});
          },
          currentIndex: selectedindex,
          items:[
            BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
            BottomNavigationBarItem(icon: Image.asset("assets/images/megaphone.png",width: 25,height: 25,), label: 'Announcements'),
            BottomNavigationBarItem(icon:Image.asset("assets/images/profilewhite.png",width: 25,height: 25,),label: 'Profile'),
            BottomNavigationBarItem(icon: Icon(Icons.notifications), label: 'Notifications'),
          ]),
    );
  }
}
