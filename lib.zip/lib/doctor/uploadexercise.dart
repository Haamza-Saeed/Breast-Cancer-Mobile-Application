import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/admin/adminrootpage.dart';
import 'package:project/doctor/doctorrootpage.dart';


class UploadExercise extends StatelessWidget {
  const UploadExercise({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              overflow: TextOverflow.visible,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xff00AEEF),
              ),
            ),
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: const Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
                child: IconButton(
                  icon: const Icon(
                    Icons.arrow_back_ios_new,
                    color: Color(0xff00AEEF),
                    size: 18,
                  ),
                  onPressed: () {
                    Navigator.push(context, MaterialPageRoute(builder: (context)=> DoctorRootPage()));
                  },
                ),
              ),
            ),
            Image.asset("assets/images/uploadexercise.png",width: 373, height: 249,),
            SizedBox(height: 10,),

            Text("Upload Exercise ",style: GoogleFonts.poppins(
              fontWeight: FontWeight.w700,
              fontSize: 27,
              color: Color(0xff00AEEF),
            ),),

            const SizedBox(height: 15),
            Align(
              alignment: Alignment.centerLeft,
              child: Text("Title",style: GoogleFonts.poppins(
                color:Color(0xff00AEEF),
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),),
            ),
            TextField(
              decoration: InputDecoration(
                isDense: true,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 10,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
              ),
            ),

            SizedBox(height: 20,),
            Align(
              alignment: Alignment.centerLeft,
              child: Text("Description",style: GoogleFonts.poppins(
                color: const Color(0xff00AEEF),
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),),
            ),
            TextField(
              maxLines: 2,
              decoration: InputDecoration(
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 15,
                  vertical: 8,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color:Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: const BorderSide(
                    color: Color(0xff00AEEF),
                    width: 2,
                  ),
                ),
              ),
            ),

            const SizedBox(height: 15),
            Align(
              alignment: Alignment.centerLeft,
              child: Text("Select Media",style: GoogleFonts.poppins(
                color:Color(0xff00AEEF),
                fontWeight: FontWeight.w700,
                fontSize: 16,
              ),),
            ),
            
            Center(child: IconButton(onPressed: (){}, icon: Icon(Icons.upload_file_rounded,size: 50,color: Colors.black,)),),

            SizedBox(height: 160,),


            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
Navigator.push(context, MaterialPageRoute(builder: (context)=>AdminRootPage()));
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xff00AEEF),
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: FittedBox(
                  fit: BoxFit.scaleDown,
                  child: Text(
                    "Upload",
                    style: GoogleFonts.poppins(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      color: const Color(0xffFFFFFF),
                    ),
                  ),
                ),
              ),
            ),




          ],),
        ),
      ),
    );
  }
}
