import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:project/Description.dart';
import 'package:project/admin/addadoctor.dart';
import 'package:project/admin/adminannouncements.dart';
import 'package:project/admin/adminfeedback.dart';
import 'package:project/admin/adminhomepage.dart';
import 'package:project/admin/adminmanageprofile.dart';
import 'package:project/admin/adminmanageusers.dart';
import 'package:project/admin/adminnotification.dart';
import 'package:project/admin/adminrootpage.dart';
import 'package:project/admin/adminsettings.dart';
import 'package:project/admin/editprofile.dart';
import 'package:project/admin/manageexercise.dart';
import 'package:project/admin/monitorchat.dart';
import 'package:project/admin/viewdoctors.dart';
import 'package:project/doctor/chatroom.dart';
import 'package:project/doctor/chatwithpatients.dart';
import 'package:project/doctor/doctorchatrequest.dart';
import 'package:project/doctor/doctorfeedback.dart';
import 'package:project/doctor/doctorhomepage.dart';
import 'package:project/doctor/doctormanageprofile.dart';
import 'package:project/doctor/doctornotification.dart';
import 'package:project/doctor/doctorrootpage.dart';
import 'package:project/doctor/doctorsettings.dart';
import 'package:project/doctor/patientprofile.dart';
import 'package:project/patient/aboutus.dart';
import 'package:project/patient/announcements.dart';
import 'package:project/patient/chatarequest.dart';
import 'package:project/patient/chatwithdoctor.dart';
import 'package:project/patient/diagnosesymptom.dart';
import 'package:project/patient/doctorprofile.dart';
import 'package:project/patient/feedback.dart';
import 'package:project/patient/homepage.dart';
import 'package:project/patient/notifications.dart';
import 'package:project/patient/profile.dart';
import 'package:project/patient/report.dart';
import 'package:project/patient/requestchat.dart';
import 'package:project/patient/rootpage.dart';
import 'package:project/patient/settings.dart';
import 'package:project/patient/uploadimage.dart';
import 'package:project/signup1.dart';


// -------------------- IMMERSIVE OBSERVER (keeps nav bar hidden after navigation) --------------------
class ImmersiveObserver extends NavigatorObserver with WidgetsBindingObserver {
  ImmersiveObserver() {
    WidgetsBinding.instance.addObserver(this);
  }

  Future<void> _applyImmersive() async {
    await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);
  }

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    _applyImmersive();
    super.didPush(route, previousRoute);
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    _applyImmersive();
    super.didPop(route, previousRoute);
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    _applyImmersive();
    super.didReplace(newRoute: newRoute, oldRoute: oldRoute);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _applyImmersive();
    }
  }

  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
  }
}

// -------------------- GLOBAL SAFEAREA WRAPPER (adds bottom space on all screens) --------------------
class GlobalSafeArea extends StatelessWidget {
  final Widget child;
  const GlobalSafeArea({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      bottom: true, // ✅ keeps bottom space on every screen
      top: false,   // ✅ keep appbars normal at top
      child: child,
    );
  }
}

// -------------------- MAIN --------------------
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Hide Back/Home/Recent at app start
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.immersiveSticky);

  // Optional: transparent system bars
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    systemNavigationBarColor: Colors.transparent,
  ));

  runApp(const MyApp());
}

// -------------------- APP --------------------
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  static final ImmersiveObserver _immersiveObserver = ImmersiveObserver();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'BreastScan AI',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepPurple),
        useMaterial3: true,
      ),

      // ✅ keeps nav bar hidden after every navigation
      navigatorObservers: [_immersiveObserver],

      // ✅ adds bottom spacing on every screen
      builder: (context, child) {
        return GlobalSafeArea(child: child ?? const SizedBox.shrink());
      },

      home: const Description(),
    );
  }
}