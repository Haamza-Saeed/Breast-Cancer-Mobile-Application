import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:project/doctor/doctorrootpage.dart';
import 'package:project/patient/chatarequest.dart';
import 'package:project/patient/rootpage.dart';

class ChatRequest extends StatefulWidget {
  const ChatRequest({super.key});

  @override
  State<ChatRequest> createState() => _ChatRequestState();
}

class _ChatRequestState extends State<ChatRequest> {
  String? selectedDoctor;

  List<String> doctors = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        titleSpacing: 0,
        leading: Padding(
          padding: const EdgeInsets.only(left: 8.0),
          child: Image.asset(
            "assets/images/ribon.png",
            width: 24,
          ),
        ),
        title: Align(
          alignment: Alignment.centerLeft,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Text(
              "AI-Based Breast Cancer Detection App",
              maxLines: 1,
              style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 15,
                color: const Color(0xffFF67CE),
              ),
            ),
          ),
        ),
      ),

      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          child: Column(
            children: [
              Align(
                alignment: Alignment.centerLeft,
                child: Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color(0xffFF67CE),
                      width: 2,
                    ),
                  ),
                  child: IconButton(
                    icon: const Icon(
                      Icons.arrow_back_ios_new,
                      color: Color(0xffFF67CE),
                      size: 18,
                    ),
                    onPressed: () {
                           Navigator.push(context, MaterialPageRoute(builder: (context)=> ChataRequest()));
                    },
                  ),
                ),
              ),

              Image.asset("assets/images/notification.png",width: 373, height: 249,),


              Text("Chat a Request",style: GoogleFonts.poppins(
                fontWeight: FontWeight.w700,
                fontSize: 27,
                color: Color(0xffFF67CE),
              ),),

              const SizedBox(height: 20),

              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  "Doctors",
                  style: GoogleFonts.poppins(
                    color: Color(0xffFF67CE),
                    fontWeight: FontWeight.w700,
                    fontSize: 18,
                  ),
                ),
              ),

              const SizedBox(height: 8),

              DropdownButtonFormField<String>(
                value: selectedDoctor,
                hint: Text(
                  "Select Doctor",
                  style: GoogleFonts.poppins(color: const Color(0xffFF67CE),),
                ),
                decoration: InputDecoration(
                  contentPadding:
                  const EdgeInsets.symmetric(horizontal: 15, vertical: 15),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: const Color(0xffFF67CE), width: 2),
                  ),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: const Color(0xffFF67CE), width: 2),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                    borderSide:
                    const BorderSide(color: const Color(0xffFF67CE), width: 2),
                  ),
                ),
                icon: const Icon(
                  Icons.arrow_drop_down_circle_outlined,
                  color: const Color(0xffFF67CE),
                ),

                items: doctors.map((doctor) {
                  return DropdownMenuItem<String>(
                    value: doctor,
                    child: Text(
                      doctor,
                      style: GoogleFonts.poppins(
                        color: const Color(0xffFF67CE),
                        fontSize: 15,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  );
                }).toList(),

                onChanged: (value) {
                  setState(() {
                    selectedDoctor = value;
                  });
                },
              ),

              const SizedBox(height: 200),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
Navigator.push(context, MaterialPageRoute(builder: (context)=>DoctorRootPage()));
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:const Color(0xffFF67CE),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                    ),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Text(
                      "Request",
                      style: GoogleFonts.poppins(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
